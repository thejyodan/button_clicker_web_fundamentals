function changeTextToLogout(element){
    element.innerText=
    "logout"
}

function RemoveAddDef(element){
    element.innerText= ""
}

function alertninja(element){
    element.innerText= "ninja was liked"
    alert("ninja was click")
}